import React from 'react'

export default function NewsCategory() {
    return (
        <div>
            NewsCategory
        </div>
    )
}
