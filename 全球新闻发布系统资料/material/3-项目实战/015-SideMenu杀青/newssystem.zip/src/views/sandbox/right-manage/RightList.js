import React from 'react'

export default function RightList() {
    return (
        <div>
            RightList
        </div>
    )
}
