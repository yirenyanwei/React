import React from 'react'

export default function NewsDraft() {
    return (
        <div>
            NewsDraft
        </div>
    )
}
