import React from 'react'

export default function Unpublished() {
    return (
        <div>
            Unpublished
        </div>
    )
}
