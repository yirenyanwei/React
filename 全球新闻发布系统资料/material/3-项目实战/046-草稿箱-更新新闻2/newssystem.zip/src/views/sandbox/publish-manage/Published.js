import React from 'react'

export default function Published() {
    return (
        <div>
            Published
        </div>
    )
}
