import React from 'react'

export default function Nopermission() {
    return (
        <div>
           403  Nopermission
        </div>
    )
}
