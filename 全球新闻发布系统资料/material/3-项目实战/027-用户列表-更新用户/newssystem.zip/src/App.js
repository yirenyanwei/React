import IndexRouter from './router/IndexRouter'
import './App.css'
function App(){
  return <IndexRouter></IndexRouter>
}
export default App