import React from 'react'

export default function NewsAdd() {
    return (
        <div>
            NewsAdd
        </div>
    )
}
