export const CollApsedReducer = (prevState={
    isCollapsed:true
},action)=>{

    return prevState
}