import axios from 'axios'

axios.defaults.baseURL="http://localhost:5000"

// axios.defaults.headers

// axios.interceptors.request.use
// axios.interceptors.response.use