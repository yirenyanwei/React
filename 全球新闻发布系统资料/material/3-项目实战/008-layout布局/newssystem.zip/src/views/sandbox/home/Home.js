import React from 'react'
import { Button } from 'antd';

export default function Home() {
    return (
        <div>
            <Button type="primary">Button</Button>
        </div>
    )
}
