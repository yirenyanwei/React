import React from 'react'

export default function Detail() {
    return (
        <div>
            Detail
        </div>
    )
}
