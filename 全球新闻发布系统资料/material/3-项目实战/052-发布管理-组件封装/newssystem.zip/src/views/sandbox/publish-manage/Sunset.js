import React from 'react'

export default function Sunset() {
    return (
        <div>
            Sunset
        </div>
    )
}
