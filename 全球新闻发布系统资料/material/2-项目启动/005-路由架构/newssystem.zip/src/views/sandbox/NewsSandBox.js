import React from 'react'

export default function NewsSandBox() {
    return (
        <div>
            NewsSandBox
        </div>
    )
}
