import React from 'react'

export default function SideMenu() {
    return (
        <div>
            SideMenu
        </div>
    )
}
