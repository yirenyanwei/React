import IndexRouter from './router/IndexRouter'

function App(){
  return <div>
     <IndexRouter></IndexRouter>
  </div>
}
export default App