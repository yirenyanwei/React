import Child from './Child'
import './App.css'
function App(){
  return <div>
    app
      <ul>
        <li>11111</li>
        <li>22222</li>
      </ul>
    <Child/>
  </div>
}

export default App