import IndexRouter from './router/IndexRouter'
import './App.css'
function App(){
  return <div>
     <IndexRouter></IndexRouter>
  </div>
}
export default App